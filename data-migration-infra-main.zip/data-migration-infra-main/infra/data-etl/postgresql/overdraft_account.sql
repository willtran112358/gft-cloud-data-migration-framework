INSERT INTO stagingdb_account AS
SELECT
  a.id,
  a.smart_contract_version_id,
  a.stakeholder_ids,
  a.alias,
  a.status,
  a.source_open_timestamp,
  a.source_open_timestamp
  a.permitted_denominations,
  -- Single parameter_values_od + nested fixed_interest_rate_od
  to_jsonb(jsonb_build_object(
    'id', pv.id,
    'accrual_precision', pv.accrual_precision,
    'application_precision', pv.application_precision,
    'current_account_id', pv.current_account_id,
    'days_in_year', pv.days_in_year,
    'debt_group', pv.debt_group,
    'denomination', pv.denomination,
    'fixed_interest_term', pv.fixed_interest_term,
    'grace_period_for_interest', pv.grace_period_for_interest,
    'interest_repayment_method', pv.interest_repayment_method,
    'maximum_interest_rate', pv.maximum_interest_rate,
    'minimum_interest_rate', pv.minimum_interest_rate,
    'original_maturity_date', pv.original_maturity_date,
    'penalty_interest_rate_account', pv.penalty_interest_rate_account,
    'penalty_principal_rate_multiplier_account', pv.penalty_principal_rate_multiplier_account,
    'write_off', pv.write_off,
    'overdraft_account_status', pv.overdraft_account_status,
    'start_from_actual_due_date', pv.start_from_actual_due_date,
    'subterm_length', pv.subterm_length,
    'fixed_interest_rate_schedule', (
      SELECT jsonb_agg(jsonb_build_object(
        'id', fir.id,
        'start_date', fir.start_date,
        'end_date', fir.end_date,
        'rate', fir.rate
      ))
      FROM fixed_interest_rate_od fir
      WHERE fir.parameter_values_id = pv.id
    )
  )) AS parameter_values
FROM account a
LEFT JOIN parameter_values_od pv ON a.id = pv.account_id