INSERT INTO stagingdb_accounts AS
SELECT
  a.id,
  a.smart_contract_version_id,
  a.stakeholder_ids,
  a.alias,
  a.status,
  a.source_create_timestamp ,
  a.source_open_timestamp ,
  a.permitted_denominations,

  -- Single parameter_values object with nested withdrawals and blockades
  to_jsonb(jsonb_build_object(
    'id', pv.id,
    'account_status_requested_by', pv.account_status_requested_by,
    'accrual_precision', pv.accrual_precision,
    'add_on_principal_days_before_maturity', pv.add_on_principal_days_before_maturity,
    'add_on_principal_during_tenure', pv.add_on_principal_during_tenure,
    'add_on_principal_on_maturity_day', pv.add_on_principal_on_maturity_day,
    'adjusted_interest_day', pv.adjusted_interest_day,
    'application_precision', pv.application_precision,
    'branch_internal_account', pv.branch_internal_account,
    'customer_nominated_account', pv.customer_nominated_account,
    'denomination', pv.denomination,
    'deposit_non_term_interest_code', pv.deposit_non_term_interest_code,
    'desired_maturity_date', pv.desired_maturity_date,
    'immediate_interest_date', pv.immediate_interest_date,
    'interest_application_frequency', pv.interest_application_frequency,
    'interest_application_type', pv.interest_application_type,
    'interest_resolve_type', pv.interest_resolve_type,
    'margin_interest_rate', pv.margin_interest_rate,
    'minimum_balance', pv.minimum_balance,
    'minimum_balance_after_partial_withdrawal', pv.minimum_balance_after_partial_withdrawal,
    'minimum_initial_deposit', pv.minimum_initial_deposit,
    'minimum_partial_withdrawal_amount', pv.minimum_partial_withdrawal_amount,
    'multiple_deposit_allowed', pv.multiple_deposit_allowed,
    'number_of_days_to_end_reminder_return_withdrawal', pv.number_of_days_to_end_reminder_return_withdrawal,
    'number_of_days_to_start_reminder_return_withdrawal', pv.number_of_days_to_start_reminder_return_withdrawal,
    'proposed_deposit_amount', pv.proposed_deposit_amount,
    'rollover_option', pv.rollover_option,
    'savings_account_status', pv.savings_account_status,
    'term_start_date', pv.term_start_date,
    'withdrawal_amount', pv.withdrawal_amount,
    'new_interest_rate_update_method', pv.new_interest_rate_update_method,

    -- Nested: withdrawal_tracker_sa
    'withdrawal_tracker', (
      SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'id', wt.id,
        'withdrawal_date', wt.withdrawal_date,
        'amount', wt.amount
      )), '[]'::jsonb)
      FROM withdrawal_tracker_sa wt
      WHERE wt.parameter_values_id = pv.id
    ),

    -- Nested: blockade_sa
    'blockade', (
      SELECT COALESCE(jsonb_agg(jsonb_build_object(
        'id', b.id,
        'start_date', b.start_date,
        'end_date', b.end_date,
        'block_amount', b.block_amount
      )), '[]'::jsonb)
      FROM blockade_sa b
      WHERE b.parameter_values_id = pv.id
    )
  )) AS parameter_values

FROM account a
LEFT JOIN parameter_values_sa pv ON pv.account_id = a.id;