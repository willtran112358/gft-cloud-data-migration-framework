######################################################
# Account Specific Variables
######################################################
region      = "ap-southeast-1"
environment = "uat"
prefix        = "gft-dm"
iacgroup      = "data-etl"
# sns_event_arn = "arn:aws:sns:ap-southeast-1:699955796816:sns_event_bucket"

# sns_event_arn = "arn:aws:sns:ap-southeast-1:699955796816:sns_event_bucket"
sns_event_arn = "arn:aws:sns:ap-southeast-1:699955796816:gft-dm-sns_event_bucket"
aws_account   = "699955796816"

######################################################
# Crawler variables
######################################################
csv-raw-crawler-tags               = { Functionality = "csv-raw" }
global-reconciliation-crawler-tags = { Functionality = "global-reconciliator" }

######################################################
# Glue jobs variables
######################################################
number_of_workers             = 2
create_balance_calculator_job = false

######################################################
# variables need by step functions
######################################################
# eks_endpoint                          = "https://.gr7.ap-southeast-1.eks.amazonaws.com"
eks_endpoint                          = "https://763824088AD2AA0A6791099333880C05.gr7.ap-southeast-1.eks.amazonaws.com"
global_reconciliation_image           = "377860792308.dkr.ecr.ap-southeast-1.amazonaws.com/ecr-apse1-cicdhdbank/uat/data-migration-infra.global-reconciliator-api:latest"
sf_deploy_job_producer_customer_image = "377860792308.dkr.ecr.ap-southeast-1.amazonaws.com/ecr-apse1-cicdhdbank/uat/data-migration-infra.dl-customer-p:latest"
sf_deploy_job_producer_account_image  = "377860792308.dkr.ecr.ap-southeast-1.amazonaws.com/ecr-apse1-cicdhdbank/uat/data-migration-infra.dl-account-p:latest"
sf_deploy_job_producer_posting_image  = "377860792308.dkr.ecr.ap-southeast-1.amazonaws.com/ecr-apse1-cicdhdbank/uat/data-migration-infra.dl-posting-p:latest"

######################################################
# variables need by Lambda functions
######################################################
aws_lambda_pandas_layer = "arn:aws:lambda:ap-southeast-1:336392948345:layer:AWSSDKPandas-Python39:18"



############################################################
### GENERAL & TAGGING
############################################################

aws_account_id         = "699955796816"
aws_region             = "ap-southeast-1"
aws_availability_zones = ["ap-southeast-1a", "ap-southeast-1b", "ap-southeast-1c"]

env_tags = {
  "region_prefix"   = "apse1"
  "account_prefix"  = "data-migration"
  "env_code_prefix" = "uat"
}
global_tags = {
  "Project"            = "DataMigration"
  "Environment"        = "UAT"
  "Terraform"          = "True"
  "BusinessUnit"       = "HDBank"
  "DataClassification" = "HighlyConfidential"
  "BusinessOwner"      = "tamds2@hdbank.com.vn"
  "ServiceOwner"       = "tamds2@hdbank.com.vn"
  "SystemOwner"        = "tamds2@hdbank.com.vn"
  "BillingRoute"       = "G1"
  "map-migrated"       = "mig4BISQ7O0D5"
}
instance_tags = {
  "Team_imi_managed" = "AWS"
  "ServerRole"       = "Container"
  "OS"               = "Linux"
}

############################################################
### EKS CLUSTER
############################################################
vpc_id                     = "vpc-0962cb9f6bcc7a99a"
subnet_ids                 = ["subnet-003242a8defe1c019", "subnet-0bb4ad82d014744e7", "subnet-0b4ee9787b4a2b930"]
k8s_version                = "1.31"
node_ami_name              = "amazon-eks-node-1.31-v20250123"
control_plane_access_cidrs = ["10.0.0.0/8", "192.168.160.0/21"]
eks_node_ami_type          = "AL2_x86_64"
eks_node_instance_types    = ["m5.2xlarge", "m5.xlarge"]
eks_node_disk_size         = 50
desired_nodepool_size      = "3"
default_nodepool_max_size  = "6"
default_nodepool_min_size  = "3"
control_plane_subnet       = "digital_core_vpc-control-plan"
node_pod_subnet            = "digital_core_vpc-container"
aws_auth_roles = [
  #  {
  #    rolearn  = data.aws_caller_identity.current.arn
  #    username = "me"
  #    groups   = ["system:masters"]
  #  },
]
ssh_key_name           = "key-apse1-uat-digital-core"
instance_type_overides = "m6i.2xlarge"
use_spot_instances     = false
subnet_ranges          = ["100.96.0.0/16", "100.97.0.0/16", "100.98.0.0/16"]
subnets_kafka_access   = ["100.96.0.0/16", "100.97.0.0/16", "100.98.0.0/16"]
subnets_by_zone = {
  "ap-southeast-1a" = "subnet-058b30ddd6e68b54b"
  "ap-southeast-1b" = "subnet-03d06e9e10bf8f262"
  "ap-southeast-1c" = "subnet-0428d5863376c7e7e"
}

# ----------------------------------------
# EKS ADDONS
# ----------------------------------------  
enable_ebs_csi_driver       = true
enable_efs_csi_driver       = true
enable_otel_collector       = false
enable_lb_controller        = true
enable_fluentbit_cloudwatch = true
ebs_addon_version           = "v1.40.1-eksbuild.1"
efs_addon_version           = "v1.7.7-eksbuild.1"
otel_addon_version          = "v0.43.0-eksbuild.1"


############################################################
### ROUTE 53
############################################################
domain_name    = "hdbank.com.vn"
db_record_name = "db"

############################################################
### AWS KMS
############################################################
kms_alias_name = "alias/key-msk"

############################################################
### AWS MSK
############################################################
kafka_version          = "3.5.1"
number_of_broker_nodes = 3
msk_primary_key        = "msk01"
broker_node_group_info = {
  instance_type   = "kafka.m5.large"
  ebs_volume_size = 1000
  subnet          = "digital_core_vpc-data-streaming"
}
add_msk_secret = true
secret_arn_list = [
  "arn:aws:secretsmanager:ap-southeast-1:699955796816:secret:AmazonMSK_digital-core-stage/msk-credential-2ZSlb1"

]
msk_allowed_cidrs = ["100.96.0.0/16", "100.97.0.0/16", "100.98.0.0/16"]
msk_subnet_ids    = ["subnet-08175bc3453600e8e", "subnet-01e2dbf78299596d5", "subnet-09c5dac1bd32dd17c"]

############################################################
### Secret Managers
############################################################
secret_managers = [
  {
    create_password = true
    secret_name     = "AmazonRDS_data-migration/rds-credentials"
    belong          = "rds01"
  }
  # ,
  # {
  #   create_password   = true
  #   secret_kms_key_id = "alias/key-msk"
  #   secret_name       = "AmazonMSK_digital-core-stage/msk-credential"
  #   belong            = "msk01"
  #   secret_string = {
  #     username = "kafka_admin"
  #   }
  #   iam_policies = [
  #     {
  #       sid    = "AWSKafkaResourcePolicy"
  #       effect = "Allow"
  #       principals = {
  #         type        = "Service"
  #         identifiers = ["kafka.amazonaws.com"]
  #       }
  #       actions = ["secretsmanager:getSecretValue"]
  #     }
  #   ]
  # }
]

############################################################
### RDS AURORA POSTGRESQL
############################################################
db_name                         = "rds-postgress-apse1-uat-data-migration"
db_family                       = "postgres15"
db_version                      = "15.8"
db_username                     = "postgres"
db_secret_manager               = "AmazonRDS_data-migration/rds-credentials"
db_storage_type                 = "gp3"
db_instance_class               = "db.m5.xlarge"
db_allocated_storage            = "50"
db_max_allocated_storage        = "100"
db_subnet_group                 = ["subnet-005df2186cda25330", "subnet-036f34b4f6e4ef769", "subnet-097141126d8ab616a"]
db_multi_az                     = false
db_deletion_protection          = true
db_performance_insights_enabled = true
db_backup_window                = "04:46-05:16"
db_backup_retention_period      = "7"
db_maintenance_window           = "Sat:00:00-Sat:03:00"
# environment = "STG"
project = "data-migration-uat"
db_parameter_group = [
  {
    name         = "log_statement"
    value        = "ddl"
    apply_method = "pending-reboot"
  },
  {
    name         = "log_min_duration_statement"
    value        = "4000"
    apply_method = "pending-reboot"
  },
  {
    name         = "rds.logical_replication"
    value        = "1"
    apply_method = "pending-reboot"
  },
  {
    name         = "max_wal_senders"
    value        = "15"
    apply_method = "pending-reboot"
  },
  {
    name         = "max_replication_slots"
    value        = "15"
    apply_method = "pending-reboot"
  },
  {
    name         = "rds.force_ssl"
    value        = "1"
    apply_method = "pending-reboot"
  },
  {
    name         = "timezone"
    value        = "UTC"
    apply_method = "pending-reboot"
  }
]


input_database_host = "rds-postgress-apse1-uat-data-migration-efea353b98de20ca.ckosc0eaoglw.ap-southeast-1.rds.amazonaws.com"
input_database_port = 5432
input_database_user = "postgres"
input_database_secret_name = "AmazonRDS_data-migration/rds-credentials"
input_database_db_name = "postgres"
input_database_schema_name = "staging"
postgres_to_s3_output_bucket = "s3://699955796816-ap-southeast-1-gft-dm-uat-raw"